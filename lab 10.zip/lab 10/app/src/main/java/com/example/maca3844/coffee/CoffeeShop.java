package com.example.maca3844.coffee;

/**
 * Created by maca3844 on 11/17/15.
 */
public class CoffeeShop {
    private String coffeeShop;
    private String coffeeShopURL;

    private void setCoffeeInfo(String coffeeCrowd) {
        switch (coffeeCrowd) {
            case "cycling":
                coffeeShop = "Amante";
                coffeeShopURL = "https.//www.amantecoffee.com";
                break;
            case "popular":
                coffeeShop = "Starbucks";
                coffeeShopURL = "https.//www.starbucks.com";
                break;
            case "hipster":
                coffeeShop = "Ozo";
                coffeeShopURL = "https.//www.ozocoffee.com";
                break;
            case "hippie":
                coffeeShop = "Trident";
                coffeeShopURL = "https.//www.tridentcafe.com";
                break;
            case "tea":
                coffeeShop = "Pekoe";
                coffeeShopURL = "https.//www.pekoesiphouse.com";
                break;
            case "college":
                coffeeShop = "Buchanans";
                coffeeShopURL = "https.//www.buchananscoffeepub.com";
                break;
            default:
                coffeeShop = "none";
                coffeeShopURL = "https://www.google.com/search?q=boulder+coffee+shops&ie=utf-8&oe=utf-8";

        }
    }

    public void setCoffeeShop(String coffeeCrowd) {
        setCoffeeInfo(coffeeCrowd);
    }

    public void setCoffeeShopURL(String coffeeCrowd) {
        setCoffeeInfo(coffeeCrowd);
    }

    public String getCoffeeShop() {
        return coffeeShop;
    }

    public String getCoffeeShopURL() {
        return coffeeShopURL;
    }
}
