package com.example.maca3844.project3;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;


public class ReceiveMountainActivity extends AppCompatActivity {

    private String mountain;
    private String mountainURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_mountain);


        Intent intent = getIntent();
        mountain = intent.getStringExtra("mountainName");
        mountainURL = intent.getStringExtra("mountainURL");
        System.out.println(mountain);
        System.out.println(mountainURL);


        TextView messageView = (TextView) findViewById(R.id.coffeeShopTextView);
        messageView.setText("You should ride at " + mountain);
    }

    public void loadWebSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(mountainURL));
        startActivity(intent);
    }
}
