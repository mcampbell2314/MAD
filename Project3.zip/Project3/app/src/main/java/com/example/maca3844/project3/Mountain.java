package com.example.maca3844.project3;

/**
 * Created by maca3844 on 12/15/15.
 */
public class Mountain {

    private String mountain;
    private String mountainURL;
    private void setMountainInfo(String mountainStyle){
        switch (mountainStyle){
        case "powder":
            mountain="Breckenridge"; mountainURL="https://www.breckenridge.com"; break;
        case "park":
            mountain="Keystone"; mountainURL="https://www.keystoneresort.com"; break;
        case "backcountry":
            mountain="Vail"; mountainURL="https://www.vail.com"; break;
        case "spring skiing":
            mountain="Arapahoe Basin"; mountainURL="http://www.arapahoebasin.com"; break;
        default:
            mountain="none"; mountainURL="https://www.google.com/#q=colorado+ski+resorts"; }
    }
    public void setMountain(String mountainStyle){
        setMountainInfo(mountainStyle);
    }
    public void setMountainURL(String mountainStyle){ setMountainInfo(mountainStyle);
    }
    public String getMountain(){ return mountain;
    }
    public String getMountainURL(){ return mountainURL;
    } }