package com.example.maca3844.project3;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Spinner;


public class FindMainActivity extends AppCompatActivity {

    private Mountain myMountain = new Mountain();

    public void findMountain(View view){
        Spinner styleSpinner = (Spinner)findViewById(R.id.spinner);
        String style = String.valueOf(styleSpinner.getSelectedItem());
        myMountain.setMountain(style);
        String suggestedMountain = myMountain.getMountain();
        String suggestedMountainURL = myMountain.getMountainURL();
        System.out.println(suggestedMountain);
        System.out.println(suggestedMountainURL);

        Intent intent = new Intent(this, ReceiveMountainActivity.class);

        intent.putExtra("MountainName", suggestedMountain);
        intent.putExtra("MountainURL", suggestedMountainURL);

        startActivity(intent);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_coffee);
    }
}
