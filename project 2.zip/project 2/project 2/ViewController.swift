//
//  ViewController.swift
//  project 2
//
//  Created by Matthew Tyler Campbell on 10/26/15.
//  Copyright (c) 2015 Matthew Tyler Campbell. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var imageA: UIImageView!
    @IBOutlet var imageB: UIImageView!
    @IBOutlet var imageC: UIImageView!
    @IBOutlet var imageD: UIImageView!
    @IBOutlet var imageE: UIImageView!
    @IBOutlet var imageF: UIImageView!
    @IBOutlet var imageG: UIImageView!
    @IBOutlet var imageH: UIImageView!
    @IBOutlet var imageI: UIImageView!
    @IBOutlet var imageJ: UIImageView!
    @IBOutlet var imageK: UIImageView!
    @IBOutlet var imageL: UIImageView!
    @IBOutlet var imageM: UIImageView!
    @IBOutlet var imageN: UIImageView!
    @IBOutlet var imageO: UIImageView!
    @IBOutlet var imageP: UIImageView!
    @IBOutlet var imageQ: UIImageView!
    @IBOutlet var imageR: UIImageView!
    @IBOutlet var imageS: UIImageView!
    @IBOutlet var imageT: UIImageView!
    @IBOutlet var imageU: UIImageView!
    @IBOutlet var imageV: UIImageView!
    @IBOutlet var imageW: UIImageView!
    @IBOutlet var imageX: UIImageView!
    @IBOutlet var imageY: UIImageView!
    @IBOutlet var imageZ: UIImageView!
    @IBOutlet var imageAb: UIImageView!
    @IBOutlet var imageBb: UIImageView!
    @IBOutlet var imageCb: UIImageView!
    @IBOutlet var imageDb: UIImageView!
    @IBOutlet var imageEb: UIImageView!
    @IBOutlet var imageFb: UIImageView!
    @IBOutlet var imageGb: UIImageView!
    @IBOutlet var imageHb: UIImageView!
    @IBOutlet var imageIb: UIImageView!
    @IBOutlet var imageJb: UIImageView!
    @IBOutlet var imageKb: UIImageView!
    @IBOutlet var imageLb: UIImageView!
    @IBOutlet var imageMb: UIImageView!
    @IBOutlet var imageNb: UIImageView!
    @IBOutlet var imageOb: UIImageView!
    @IBOutlet var imagePb: UIImageView!
    @IBOutlet var imageQb: UIImageView!
    @IBOutlet var imageRb: UIImageView!
    @IBOutlet var imageSb: UIImageView!
    @IBOutlet var imageTb: UIImageView!
    @IBOutlet var imageUb: UIImageView!
    @IBOutlet var imageVb: UIImageView!
    @IBOutlet var imageWb: UIImageView!
    @IBOutlet var imageXb: UIImageView!
    @IBOutlet var imageYb: UIImageView!
    @IBOutlet var imageZb: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {for touch in (touches as! Set<UITouch>) {
        let location = touch.locationInView(self.view)
        
        if imageA.frame.contains(location){
            
            imageA.center = location
            }
        else if imageB.frame.contains(location){
            imageB.center = location
        }
        else if imageC.frame.contains(location){
            imageC.center = location
        }
        else if imageD.frame.contains(location){
            imageD.center = location
        }
        else if imageE.frame.contains(location){
            imageE.center = location
        }
        else if imageF.frame.contains(location){
            imageF.center = location
        }
        else if imageG.frame.contains(location){
            imageG.center = location
        }
        else if imageH.frame.contains(location){
            imageH.center = location
        }
        else if imageI.frame.contains(location){
            imageI.center = location
        }
        else if imageJ.frame.contains(location){
            imageJ.center = location
        }
        else if imageK.frame.contains(location){
            imageK.center = location
        }
        else if imageL.frame.contains(location){
            imageL.center = location
        }
        else if imageM.frame.contains(location){
            imageM.center = location
        }
        else if imageN.frame.contains(location){
            imageN.center = location
        }
        else if imageO.frame.contains(location){
            imageO.center = location
        }
        else if imageP.frame.contains(location){
            imageP.center = location
        }
        else if imageQ.frame.contains(location){
            imageQ.center = location
        }
        else if imageR.frame.contains(location){
            imageR.center = location
        }
        else if imageS.frame.contains(location){
            imageS.center = location
        }
        else if imageT.frame.contains(location){
            imageT.center = location
        }
        else if imageU.frame.contains(location){
            imageU.center = location
        }
        else if imageV.frame.contains(location){
            imageV.center = location
        }
        else if imageW.frame.contains(location){
            imageW.center = location
        }
        else if imageX.frame.contains(location){
            imageX.center = location
        }
        else if imageY.frame.contains(location){
            imageY.center = location
        }
        else if imageZ.frame.contains(location){
            imageZ.center = location
        }
        else if imageAb.frame.contains(location){
            imageAb.center = location
        }
        else if imageBb.frame.contains(location){
            imageBb.center = location
        }
        else if imageCb.frame.contains(location){
            imageCb.center = location
        }
        else if imageDb.frame.contains(location){
            imageDb.center = location
        }
        else if imageEb.frame.contains(location){
            imageEb.center = location
        }
        else if imageFb.frame.contains(location){
            imageFb.center = location
        }
        else if imageGb.frame.contains(location){
            imageGb.center = location
        }
        else if imageHb.frame.contains(location){
            imageHb.center = location
        }
        else if imageIb.frame.contains(location){
            imageIb.center = location
        }
        else if imageJb.frame.contains(location){
            imageJb.center = location
        }
        else if imageKb.frame.contains(location){
            imageKb.center = location
        }
        else if imageLb.frame.contains(location){
            imageLb.center = location
        }
        else if imageMb.frame.contains(location){
            imageMb.center = location
        }
        else if imageNb.frame.contains(location){
            imageNb.center = location
        }
        else if imageOb.frame.contains(location){
            imageOb.center = location
        }
        else if imagePb.frame.contains(location){
            imagePb.center = location
        }
        else if imageQb.frame.contains(location){
            imageQb.center = location
        }
        else if imageRb.frame.contains(location){
            imageRb.center = location
        }
        else if imageSb.frame.contains(location){
            imageSb.center = location
        }
        else if imageTb.frame.contains(location){
            imageTb.center = location
        }
        else if imageUb.frame.contains(location){
            imageUb.center = location
        }
        else if imageVb.frame.contains(location){
            imageVb.center = location
        }
        else if imageWb.frame.contains(location){
            imageWb.center = location
        }
        else if imageXb.frame.contains(location){
            imageXb.center = location
        }
        else if imageYb.frame.contains(location){
            imageYb.center = location
        }
        else if imageZb.frame.contains(location){
            imageZb.center = location
        }
        
        }
    }
    
    override func touchesMoved(touches: Set<NSObject>, withEvent event: UIEvent) {
        for touch in (touches as! Set<UITouch>) {
            let location = touch.locationInView(self.view)
            
            if imageA.frame.contains(location){
                
                imageA.center = location
            }
            else if imageB.frame.contains(location){
                imageB.center = location
            }
            else if imageC.frame.contains(location){
                imageC.center = location
            }
            else if imageD.frame.contains(location){
                imageD.center = location
            }
            else if imageE.frame.contains(location){
                imageE.center = location
            }
            else if imageF.frame.contains(location){
                imageF.center = location
            }
            else if imageG.frame.contains(location){
                imageG.center = location
            }
            else if imageH.frame.contains(location){
                imageH.center = location
            }
            else if imageI.frame.contains(location){
                imageI.center = location
            }
            else if imageJ.frame.contains(location){
                imageJ.center = location
            }
            else if imageK.frame.contains(location){
                imageK.center = location
            }
            else if imageL.frame.contains(location){
                imageL.center = location
            }
            else if imageM.frame.contains(location){
                imageM.center = location
            }
            else if imageN.frame.contains(location){
                imageN.center = location
            }
            else if imageO.frame.contains(location){
                imageO.center = location
            }
            else if imageP.frame.contains(location){
                imageP.center = location
            }
            else if imageQ.frame.contains(location){
                imageQ.center = location
            }
            else if imageR.frame.contains(location){
                imageR.center = location
            }
            else if imageS.frame.contains(location){
                imageS.center = location
            }
            else if imageT.frame.contains(location){
                imageT.center = location
            }
            else if imageU.frame.contains(location){
                imageU.center = location
            }
            else if imageV.frame.contains(location){
                imageV.center = location
            }
            else if imageW.frame.contains(location){
                imageW.center = location
            }
            else if imageX.frame.contains(location){
                imageX.center = location
            }
            else if imageY.frame.contains(location){
                imageY.center = location
            }
            else if imageZ.frame.contains(location){
                imageZ.center = location
            }
            else if imageAb.frame.contains(location){
                imageAb.center = location
            }
            else if imageBb.frame.contains(location){
                imageBb.center = location
            }
            else if imageCb.frame.contains(location){
                imageCb.center = location
            }
            else if imageDb.frame.contains(location){
                imageDb.center = location
            }
            else if imageEb.frame.contains(location){
                imageEb.center = location
            }
            else if imageFb.frame.contains(location){
                imageFb.center = location
            }
            else if imageGb.frame.contains(location){
                imageGb.center = location
            }
            else if imageHb.frame.contains(location){
                imageHb.center = location
            }
            else if imageIb.frame.contains(location){
                imageIb.center = location
            }
            else if imageJb.frame.contains(location){
                imageJb.center = location
            }
            else if imageKb.frame.contains(location){
                imageKb.center = location
            }
            else if imageLb.frame.contains(location){
                imageLb.center = location
            }
            else if imageMb.frame.contains(location){
                imageMb.center = location
            }
            else if imageNb.frame.contains(location){
                imageNb.center = location
            }
            else if imageOb.frame.contains(location){
                imageOb.center = location
            }
            else if imagePb.frame.contains(location){
                imagePb.center = location
            }
            else if imageQb.frame.contains(location){
                imageQb.center = location
            }
            else if imageRb.frame.contains(location){
                imageRb.center = location
            }
            else if imageSb.frame.contains(location){
                imageSb.center = location
            }
            else if imageTb.frame.contains(location){
                imageTb.center = location
            }
            else if imageUb.frame.contains(location){
                imageUb.center = location
            }
            else if imageVb.frame.contains(location){
                imageVb.center = location
            }
            else if imageWb.frame.contains(location){
                imageWb.center = location
            }
            else if imageXb.frame.contains(location){
                imageXb.center = location
            }
            else if imageYb.frame.contains(location){
                imageYb.center = location
            }
            else if imageZb.frame.contains(location){
                imageZb.center = location
            }
            
        }
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

