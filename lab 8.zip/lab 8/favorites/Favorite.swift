//
//  Favorite.swift
//  favorites
//
//  Created by Matthew Tyler Campbell on 10/20/15.
//  Copyright (c) 2015 Matthew Tyler Campbell. All rights reserved.
//

import Foundation

class Favorite{
    var favBook : String?
    var favAuthor : String?
}