//
//  ViewController.swift
//  project1
//
//  Created by Matthew Tyler Campbell on 9/28/15.
//  Copyright (c) 2015 Matthew Tyler Campbell. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var messageText: UILabel!
    
    @IBAction func happy(sender: UIButton) {
        if sender.tag==1{
            messageText.text="Classical, Jazz, & Reggae"
        }
        else if sender.tag==2{
            messageText.text="R&B(Soul), Jazz, & Romanance"
        }
        else if sender.tag==3{
            messageText.text="Rock, Rap, & Alternative"
        }
        else if sender.tag==4{
            messageText.text="R&B(Soul), Country, & The Blues"
        }
        else if sender.tag==5{
            messageText.text="Jazz, Reggae, & Swing"
        }
        else if sender.tag==6{
            messageText.text="Instrumentals & Psychedelic"
        }
        else if sender.tag==7{
            messageText.text="Instrumentals, Reggae, & Classical"
        }
        else if sender.tag==8{
            messageText.text="Techno(EDM), Rock, Punk & Swing"
        }
        

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

